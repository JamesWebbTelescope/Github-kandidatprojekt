# example main.py

# connect to wifi
#wifi.essid = 'your_wifi_network'
#wifi.password = 'your_wifi_password'
#wifi.scan()
##wifi.connect()

### set your clock (may take several tries)
##import time
##for x in range(3):
##    if rtc.ntp_set():
##        break
##    time.sleep_ms(500)

### watch eziot 
##eziot.api_key = 'EXAMPLE'
##eziot.api_secret = 'EXAMPLE'
##eziot.watch()


