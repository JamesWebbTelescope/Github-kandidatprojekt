#-----------------------
# funboard setup
#-----------------------

import funboard.setup as fs; del fs
st.memp(show=False)

#-----------------------
# other setup
#-----------------------

#-----------------------
# end
#-----------------------

