## Face Detection

This is the code I used to make the silly face detection video: [https://www.youtube.com/watch?v=MDUA7L48JJw](https://www.youtube.com/watch?v=MDUA7L48JJw)

I last tested/updated this code using **OpenCV 4.4.0** and **Python 3.8** on **Linux** on **March 16, 2022**. All good.

**IMPORTANT**: Set your camera address in file `` line 59.

Here are the keystrokes to change things:

1. q = **q**uit

1. b = draw **b**ox

1. m = draw **m**ustache

1. n = draw **n**ose box

1. v = draw **e**ye boxes





