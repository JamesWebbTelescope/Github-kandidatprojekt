# MicroServer

This is exact code I use to run the Beaker server on the FunBoard v1.


