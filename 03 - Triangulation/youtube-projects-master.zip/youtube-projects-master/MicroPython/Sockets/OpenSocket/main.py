# Posty Project: main.py
# Copyright (c) 2019 Clayton Darwin claytondarwin@gmail.com

# notify
print('RUN: main.py')

# run opensocket example
import opensocket_server_example

