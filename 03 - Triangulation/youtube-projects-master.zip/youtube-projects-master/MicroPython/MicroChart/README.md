# MicroChart

In Progress

This will be a small SVG-based charting/plotting application you can run with micropython.
I'll make a video when it is ready.

Clayton

