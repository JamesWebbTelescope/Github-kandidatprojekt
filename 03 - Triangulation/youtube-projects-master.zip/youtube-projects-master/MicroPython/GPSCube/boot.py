# This file is executed on every boot (including wake-boot from deepsleep)

# notify
print('RUN: boot.py')


