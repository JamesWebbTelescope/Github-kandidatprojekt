# notify
print() # clear boot codes
print('RUN: boot.py')


