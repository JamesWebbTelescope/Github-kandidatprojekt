# notify
print('RUN: main.py')

import netmon2

