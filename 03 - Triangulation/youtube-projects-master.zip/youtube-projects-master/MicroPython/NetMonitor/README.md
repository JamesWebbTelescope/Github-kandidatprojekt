Using MicroPython 1.18

You need your own `netcreds.py` file. Make it look like this:

```
essid = 'youressid'
essid_password = 'yourpassword'

youtube_api_key = 'yourkey'
finnhub_api_key = 'yourkey'

```

