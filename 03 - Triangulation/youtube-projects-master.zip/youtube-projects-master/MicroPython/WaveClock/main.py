# notify
print('RUN: main.py')

# WAVE CLOCK
try:

    import clock3 as clock # blue-wave clock
    clock.CLOCK()

except KeyboardInterrupt:
    pass

