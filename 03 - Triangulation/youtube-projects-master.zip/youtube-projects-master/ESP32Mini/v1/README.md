# The ESP32Mini V1

This is deprecated. See the ESP32Mini V2. Same idea, same pinout, same software.


