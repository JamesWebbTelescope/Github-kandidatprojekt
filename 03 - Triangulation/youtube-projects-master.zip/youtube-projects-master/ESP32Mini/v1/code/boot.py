#-----------------------
# esp32mini setup
#-----------------------

import esp32mini.setup as ems; del ems
st.memp(show=False)

#-----------------------
# other setup
#-----------------------

#-----------------------
# end
#-----------------------

