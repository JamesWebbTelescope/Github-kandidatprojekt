# Clayton's PCB Shop

Welcome to Clayton's PCB Shop.

This repository hosts the code and design files for projects you can find on my YouTube channel [ClaytonDarwin](https://www.youtube.com/claytondarwin) and in my online store [Clayton's PCB Shop](https://cpcb.shop/).

Please not that the code here may be "in progress". That is, it may or **may not be functional** depending on where I left it last. Also note that although I'm putting all my new projects here, some older projects have not been moved here yet. 

In general, I'm using a **Debian-Linux**-based desktop computer for testing and running all the **Python3** scripts, and I typically use an **ESP32-based** FunBoard for all the **MicroPython** scripts.

Feel free to use the code however you like. If it is a great benefit to you, be sure to send me something nice, like a friendly message, a bottle of wine, or even money.

Cheers,

Clayton

